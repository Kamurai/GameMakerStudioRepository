This folder contains a very simple extension package based
on an action library. The library has two actions, one to 
let the object jump to the mouse position and one to let 
it move towards the mouse position. The extension package
contains this library. The test game uses the extension
package. The extension package must be installed in Game
Maker for this game to work. All files have been provided.

WARNING: To change the extension package you will have to
reindicate what the location of the action library is because
it will have a different location on your own machine!
